function ExecuteScript(strId)
{
  switch (strId)
  {
      case "65LDPvhkUIz":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

